/**
 * Main trida, spousti celou hru
 */
public class Main {
    public static void main(String[] args) {
        new Game();
    }
}