import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.IOException;

/**
 * Bubak
 */
public class Monster {
    int x, y, flip = 0;
    BufferedImage img;

    boolean alive = true;

    Camp camp;

    /**
     * Konstruktor
     * @param x souradnice, fakticky je y, ale je to jedno
     * @param y souradnice, taky je x
     * @param camp - proste camp, kteremu musis pomahat a chranit a bubak nicit
     */
    public Monster(int x,int y, Camp camp){
        this.x = x;
        this.y = y;
        this.camp = camp;
        try {
            this.img = ImageIO.read(getClass().getResourceAsStream("/images/monster.png"));
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    /**
     * Pohyb bubaka
     */
    public void Pohyb()
    {
        if(x > 100)
        {
            x-=3;
        } if (x < 40){
            x+=3;
        } if(y > 240){
            y-=3; flip = -1;
        } if(y < 180){
            y+=3; flip = 1;
        } if(x < 110 && x > 30 && y < 250 && y > 170)
        {
            camp.hp--;
        }
    }

    /**
     * Kresleni bubaka
     * @param g2
     */
    public void Draw(Graphics2D g2){
        if(alive) g2.drawImage(img, y, x, 3 * 16 * 3, 3 * 16 * 3, null);


    }
}
