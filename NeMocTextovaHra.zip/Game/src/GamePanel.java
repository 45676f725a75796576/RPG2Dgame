import javax.imageio.ImageIO;
import javax.swing.*;
import javax.swing.tree.TreeCellRenderer;
import java.awt.*;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.Random;

/**
 * GamePanel ridi co vidi hrac
 */
public class GamePanel extends JPanel implements Runnable{
    //SCREEN SETTINGS

    //JButton hitButton = new JButton("HIT");

    final int originalTileSize = 16;
    final int scale = 3;

    public int tileSize = originalTileSize * scale;

    final int maxScreenCol = 16;
    final int maxScreenRow = 12;

    final int screenWidth = tileSize * maxScreenCol;
    final int screenHeight = tileSize * maxScreenRow;
    Monster[] monster = new Monster[8];

    int idle = 0;

    int FPS = 15;

    KeyHandler keyH = new KeyHandler();
    Thread gameThread;
    TreesSpawn treesSpawn = new TreesSpawn(this);

    Player player = new Player(this);

    BufferedImage bg;

    Camp camp = new Camp();

    int score = 0;

    /**
     * Konstruktor
     */
    public GamePanel()
    {
        Random r = new Random();
        this.setPreferredSize(new Dimension(720, 540));
        this.setBackground(Color.getHSBColor(0.33f,1.0f,0.21f));
        this.setDoubleBuffered(true);
        this.addKeyListener(keyH);
        this.setFocusable(true);
        //add(hitButton);
        //hitButton.setBounds(new Rectangle(100,100,100,100));
        //hitButton.setVisible(true);

        TryGetBG();
        for (int i = 0; i < monster.length; i++) {
            monster[i] = new Monster(r.nextInt(480)+40, r.nextInt(720), camp);
        }
    }

    /**
     * Tato metoda spousti celou hru
     */
    public void startGameThread()
    {
        gameThread = new Thread(this);
        gameThread.start();
    }


    /**
     * Metoda proto, aby dostat background
     */
    public void TryGetBG(){
        try {
            bg = ImageIO.read(getClass().getResourceAsStream("/images/bG.png"));
        } catch (IOException e){
            e.printStackTrace();
        }
    }


    @Override
    public void run() {

        double drawInterval = 1000000000 / FPS;
        double nextDrawTime = System.nanoTime() + drawInterval;

        while (gameThread != null)
        {
            update();

            repaint();

            try {
                double remainingTime = nextDrawTime - System.nanoTime();
                remainingTime = remainingTime/1000000;

                if(remainingTime < 0){remainingTime = 0;}

                Thread.sleep((long) remainingTime);

                nextDrawTime += drawInterval;
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
        }
    }


    /**
     * Prubeh hry, stejny jako v Unity engine
     */
    public void update()
    {
        Random r = new Random();
        player.upPressed = keyH.upPressed;
        player.downPressed = keyH.downPressed;
        player.leftPressed = keyH.leftPressed;
        player.rightPressed = keyH.rightPressed;
        player.hit = keyH.hit;
        if(player.upPressed == false && player.downPressed == false && player.leftPressed == false && player.rightPressed == false){
            idle++;
        } else idle = 0;

        if(idle > 100){
            camp.hp--;
        }

        for (int i = 0; i < monster.length-1; i++) {
            monster[i].Pohyb();
        }
        for (int i = 0; i < monster.length; i++) {
            if(!monster[i].alive && camp.hp > 0){
                monster[i] = new Monster(r.nextInt(480)+40, 720, camp);
                monster[i].alive = true;

                score++;
            }
        }
    }

    /**
     * Metoda, ktera kresli grafiku pro hru
     * @param g the <code>Graphics</code> object to protect
     */
    public void paintComponent(Graphics g)
    {
        super.paintComponent(g);

        Graphics2D g2 = (Graphics2D)g;

        g2.drawImage(bg, 0,0,720,540, null);
        treesSpawn.spawn(g2);

        camp.Draw(g2);

        player.Draw(g2);
        for (int i = 0; i < monster.length-1; i++) {
            monster[i].Draw(g2);
        }

        g2.fillRect(50, 20, 620, 50);

        g2.setColor(Color.RED);
        g2.fillRect(52, 22, 614 * camp.hp / 600, 46);

        g2.setColor(Color.WHITE);
        g2.drawString("kill count: " + score, 100, 100);

        g2.dispose();


    }
}
