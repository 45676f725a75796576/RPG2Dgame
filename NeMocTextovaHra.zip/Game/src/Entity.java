import java.awt.image.BufferedImage;

public class Entity {
    BufferedImage idle, hitImg, dodge, ult;
}
