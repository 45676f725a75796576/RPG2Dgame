import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.IOException;

/**
 * Hrac
 */
public class Player extends Entity {
    GamePanel gp;

    public boolean upPressed, downPressed, leftPressed, rightPressed, hit;

    int healthPoints = 20, protection = 1, damage = 1, speed = 5;
    int finalHealth = healthPoints * protection;

    Monster[] monsters;

    int posX = 250, posY = 250;

    /**
     * Konstruktor
     * @param gamePanel
     */
    public Player(GamePanel gamePanel){
        this.gp = gamePanel;

        monsters = gamePanel.monster;

        GetPlayerImage();
    }

    /**
     * Metoda pro vyber obrazku
     */
    public void GetPlayerImage(){
        try{
            idle = ImageIO.read(getClass().getResourceAsStream("/images/pixil-frame-0 (1).png"));
            dodge = ImageIO.read(getClass().getResourceAsStream("/player/aleksej3.png"));
            ult = ImageIO.read(getClass().getResourceAsStream("/player/aleksej4.png"));
            hitImg = ImageIO.read(getClass().getResourceAsStream("/images/hit.png"));

        }catch (IOException e){
            e.printStackTrace();
        }
    }

    int flip = 1;int offset = 0;

    /**
     * Metoda pro vykresleni hrace
     * @param g2
     */
    public void Draw(Graphics2D g2)
    {


        BufferedImage _image = null;

        if(upPressed && posX > 128) posX -= speed;
        if(downPressed && posX < 524) posX += speed;
        if(leftPressed && posY > -30) {posY -= speed; flip = -1; offset = 128;}
        if(rightPressed && posY < 660) {posY += speed; flip = 1; offset = 0;}

        _image = idle;

        if(flip == -1){
            offset = 128;
        }

        g2.drawImage(_image, posY + offset,posX,  (int) (gp.tileSize * 2 * flip), gp.tileSize * 2, null);
        if(hit && flip > 0) {
            g2.drawImage(hitImg, posY + 16,posX, gp.tileSize * 2 * flip, gp.tileSize * 2, null); speed = 2;
        }
        if(hit && flip < 0) {
            g2.drawImage(hitImg, posY + offset - 16,posX, gp.tileSize * 2 * flip, gp.tileSize * 2, null); speed = 2;
        }
        if(hit){
            for (int i = 0; i < monsters.length; i++) {
                if(monsters[i].y > posY - 128 && monsters[i].y < posY && monsters[i].x < posX && monsters[i].x > posX - 128){
                    monsters[i].alive = false;
                }
            }
        }
        else if(!hit){speed = 7;}
    }
}
