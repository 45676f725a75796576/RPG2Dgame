import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.Random;

/**
 * Trida pro spawn stromu
 */
public class TreesSpawn {

    public int X[] = new int[16], Y[] = new int[16], treeCount = 16;

    GamePanel gp;

    Random r = new Random();

    public BufferedImage treesImage;

    /**
     * spawnuje randomne stromy
     * @param gp
     */
    public TreesSpawn(GamePanel gp)
    {
        this.gp = gp;
        for (int i = 0; i < treeCount; i++) {
            X[i] = r.nextInt(30)-20;
            Y[i] = r.nextInt(720)-30;
        }
        try{
            treesImage = ImageIO.read(getClass().getResourceAsStream("/images/tree.png"));
        } catch (IOException e){
            e.printStackTrace();
        }
    }

    /**
     * Metoda pro kresleni stromu
     * @param g2
     */
    public void spawn(Graphics2D g2){
        for (int i = 0; i < treeCount; i++) {
            g2.drawImage(treesImage, Y[i], X[i], (int) (gp.tileSize * 4), (int) (gp.tileSize * 4), null);
        }
    }
}
