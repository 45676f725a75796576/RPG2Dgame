import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.IOException;

/**
 * Trida pro objekt, ktery musis chranit
 */
public class Camp {
    int hp = 600;
    BufferedImage campImg;
    GamePanel gp;

    /**
     * Konstruktor
     */
    public Camp() {
        try {
            this.campImg = ImageIO.read(getClass().getResourceAsStream("/images/camp.png"));
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }


    /**
     * Metoda pro kresleni campingu
     * @param g2
     */
    public void Draw(Graphics2D g2){
        BufferedImage img = campImg;

        g2.drawImage(img, 250,20, 3 * 16 * 5,3 * 16 * 5, null);

        if(this.hp <= 0){
            g2.setColor(Color.black);
            g2.fillRect(0,0,720, 540);

            g2.setColor(Color.RED);
            g2.drawString("WASTED", 350, 200);
        }
    }
}
